self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4914f783c6e17f8af5da9d1789e3b245",
    "url": "./index.html"
  },
  {
    "revision": "2d7a618f0da71e6fc60c",
    "url": "./static/css/main.2d0dffb7.chunk.css"
  },
  {
    "revision": "0b51c1d6e848e068b8fd",
    "url": "./static/js/2.3fd5a6ae.chunk.js"
  },
  {
    "revision": "2d7a618f0da71e6fc60c",
    "url": "./static/js/main.9db621d4.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime-main.d653cc00.js"
  },
  {
    "revision": "1c9aa8d2c880d3931c9284370dd85f91",
    "url": "./static/media/1-1-fala.1c9aa8d2.svg"
  },
  {
    "revision": "af9b88ef5f472def3b0def429d60e413",
    "url": "./static/media/1-1-fala.af9b88ef.svg"
  },
  {
    "revision": "bf76f94e10271d119548f6054a215ac8",
    "url": "./static/media/1-1-fala.bf76f94e.svg"
  },
  {
    "revision": "e20d33dbb5bbd00fcc56be2c8464484f",
    "url": "./static/media/1-1-quadro.e20d33db.svg"
  },
  {
    "revision": "1a73874d685a00bb690186cdacb59423",
    "url": "./static/media/1-2-fala.1a73874d.svg"
  },
  {
    "revision": "908e24f4560c936a4303d9c6e2a56a14",
    "url": "./static/media/1-2-fala.908e24f4.svg"
  },
  {
    "revision": "f5067b07eee50e6b37c052ce57c99509",
    "url": "./static/media/1-2-fala.f5067b07.svg"
  },
  {
    "revision": "194b0ecb39c47cc2c8e65c484e5e657c",
    "url": "./static/media/1-3-fala.194b0ecb.svg"
  },
  {
    "revision": "6190b453d65d51dbf5a0682aa144698e",
    "url": "./static/media/1-3-fala.6190b453.svg"
  },
  {
    "revision": "678b1451c6b28ec7d85f6b299cd9b3ed",
    "url": "./static/media/1-3-fala.678b1451.svg"
  },
  {
    "revision": "7465215bcd77364b953a222d11ecea87",
    "url": "./static/media/1-pilares.7465215b.svg"
  },
  {
    "revision": "e7eafb89e789ec5fd5c61474b8f04e7e",
    "url": "./static/media/2-professora.e7eafb89.svg"
  },
  {
    "revision": "9c75a417dbd8ab5ae0bd8ed9dc812e2c",
    "url": "./static/media/3-1-quadro.9c75a417.svg"
  },
  {
    "revision": "321299054d8edecbc6d42d0cb7557124",
    "url": "./static/media/4-1-quadro.32129905.svg"
  },
  {
    "revision": "c9210e7c21ae62969ad670765da59786",
    "url": "./static/media/MPensando.c9210e7c.svg"
  },
  {
    "revision": "dbaddf51db030772bf36b489ee4b6abe",
    "url": "./static/media/anotacao.dbaddf51.svg"
  },
  {
    "revision": "c07cadaac13975ff4b1cd74d00a8e11c",
    "url": "./static/media/aperto.c07cadaa.svg"
  },
  {
    "revision": "bd6594b1696bbfea4d80175d362c79cc",
    "url": "./static/media/background.bd6594b1.svg"
  },
  {
    "revision": "72263ddd154955f0d0d6e3b01faa370b",
    "url": "./static/media/caminhos.72263ddd.svg"
  },
  {
    "revision": "1a4ff9fcb7b03ab7378846484644d353",
    "url": "./static/media/casas.1a4ff9fc.svg"
  },
  {
    "revision": "dc9838dc27fb8e907f27922fea943833",
    "url": "./static/media/criancas.dc9838dc.svg"
  },
  {
    "revision": "be924c68c2e59b60b96d5739326d81e9",
    "url": "./static/media/estrela.be924c68.svg"
  },
  {
    "revision": "25e4bd53193e62db50a3be69a5f6ab20",
    "url": "./static/media/fala-mariana.25e4bd53.svg"
  },
  {
    "revision": "ac3fa23f2aa1b49e4b8d1b4f03af4254",
    "url": "./static/media/fala-mariana.ac3fa23f.svg"
  },
  {
    "revision": "84ed58036095480aa9b1384ede4a605f",
    "url": "./static/media/familia.84ed5803.svg"
  },
  {
    "revision": "4bb97bfdb7f136bf33723146920d3d0e",
    "url": "./static/media/feira.4bb97bfd.svg"
  },
  {
    "revision": "a572df2596adb84d4e80b2b99e5c7cfb",
    "url": "./static/media/guarda-roupa.a572df25.svg"
  },
  {
    "revision": "4a0ed16631ebfcb7339e994305445b4e",
    "url": "./static/media/lista.4a0ed166.svg"
  },
  {
    "revision": "d023c58d636b1eb02ce236d736d5de1c",
    "url": "./static/media/logo.d023c58d.svg"
  },
  {
    "revision": "2363c0983a52a3560ae6b58c625d4ce2",
    "url": "./static/media/pensando.2363c098.svg"
  },
  {
    "revision": "1af81b6ef009122afcb32d65dae38578",
    "url": "./static/media/praca.1af81b6e.svg"
  },
  {
    "revision": "2df02e54c55e5cedbf38f3421f79bd8e",
    "url": "./static/media/presente.2df02e54.svg"
  },
  {
    "revision": "a6e4bc8cbe5303710a67d9a1cdae30be",
    "url": "./static/media/produtos.a6e4bc8c.svg"
  },
  {
    "revision": "06130adec4ab86f5eae0fbcb5f017e9a",
    "url": "./static/media/top.06130ade.svg"
  }
]);